<?php
namespace Pot\Controller;
use Think\Controller;
use Pot\Service\WxJssdk;

class IndexController extends Controller {
    public function index(){
		
    }
	
	public function demo(){
		dump($_REQUEST);
		$postStr = $GLOBALS["HTTP_RAW_POST_DATA"];
		dump($postStr);
		libxml_disable_entity_loader(true);
      	$postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
		dump($postObj);
	}
	
	public function dddddd(){
		$code = I("code");
		$token_uri = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=".C("wx_app_id")."&secret=".C("wx_app_secret")."&code={$code}&grant_type=authorization_code";
		$response = file_get_contents($token_uri);
		$response = json_decode($response, true);
		$open_id = $response['openid'];
		dump($open_id);
		session("wx_open_id", $open_id);
		echo "<a href='http://farm-api.bestfu.com/?s=Pot/Index/session_test'>session</a>";
	}
	
	public function session_test(){
		dump($_SESSION);
	}
	
	public function send_msg(){
		$wxJssdk = new WxJssdk(C("wx_app_id"), C("wx_app_secret"));
		$access_token = $wxJssdk->getAccessToken();
		$data = '
			{
			    "touser":"oDOkXwZFY4qZfEzbkb0PDAjt5XZ8",
			    "msgtype":"text",
			    "text":
			    {
			        "content":"智慧盆栽通知Hello World"
			    }
			}
		';
		$msg = $this->_curl_custom_service($access_token, $data);
		dump($msg);
	}
	
	private function _curl_custom_service($ACCESS_TOKEN,$data)
    {
		$ch = curl_init(); 
		curl_setopt($ch, CURLOPT_URL, "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=".$ACCESS_TOKEN); 
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_AUTOREFERER, 1); 
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
		$tmpInfo = curl_exec($ch); 
		if (curl_errno($ch)) {  
			echo 'Errno'.curl_error($ch);
		}
		curl_close($ch); 
		$arr= json_decode($tmpInfo,true);
		return $arr;
    }

	public function template_msg(){
		$wxJssdk = new WxJssdk(C("wx_app_id"), C("wx_app_secret"));
		$access_token = $wxJssdk->getAccessToken();
		//段//oDOkXwQklnFqYFcCrDu_cZOW8EeY
		//梁//oDOkXwZFY4qZfEzbkb0PDAjt5XZ8
		//高//oDOkXwXI44Ak728Vx57d1bdKtTG0
		$data = '
			{
			    "touser":"oDOkXwXI44Ak728Vx57d1bdKtTG0",
			    "template_id":"E3I_z3KRpTAhFGjRQhVGe84m7vEwyzKGqrfT7vnXcvY",
				"url":"http://farm.bestfu.com",
			    "topcolor":"#FF0000",
			    "data":{
		            "title": {
		                "value":"主人，我发烧了！",
		                "color":"#66CC00"
		            },
		            "name":{
		                "value":"西安贝多福测试花盆",
		                "color":"#333333"
		            },
		            "status": {
		                "value":"温度:40℃ 湿度:70% 水位:25",
		                "color":"#333333"
		            },
		            "time":{
		                "value":"'.date('Y-m-d H:i:s').'",
		                "color":"#333333"
		            }
			    }
			}
		';
		$msg = $this->_curl_template_notice($access_token, $data);
		dump($msg);
	}
	
	private function _curl_template_notice($ACCESS_TOKEN,$data)
    {
		$ch = curl_init(); 
		curl_setopt($ch, CURLOPT_URL, "https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=".$ACCESS_TOKEN); 
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_AUTOREFERER, 1); 
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
		$tmpInfo = curl_exec($ch); 
		if (curl_errno($ch)) {  
			echo 'Errno'.curl_error($ch);
		}
		curl_close($ch); 
		$arr= json_decode($tmpInfo,true);
		return $arr;
    }
}