<?php
namespace Pot\Controller;
use Think\Controller;

class DeviceController extends Controller
{
	/**
	 * 上报花盆数据
	 */
	public function report(){
		echo "report";
	}
	
	/**
	 * 上报花盆硬件信息
	 */
	public function hardware(){
		echo "hardware";
	}
	
	/**
	 * 微信用户和花盆绑定
	 */
	public function bind(){
		echo "bind";
	}
}
