<?php
/**
 * 基类controller
 * @author liangjian <liangjian@bestfu.com>
 */
namespace Pot\Controller;
use Think\Controller;

class CommonController extends Controller
{
	
}
