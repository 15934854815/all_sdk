<?php
/**
 * 网络配置controller
 * @author liangjian <liangjian@bestfu.com>
 */
namespace Pot\Controller;
use Pot\Service\WxJssdk;

class WifiController extends CommonController
{
	public function configure(){
		$wxJssdk = new WxJssdk(C("wx_app_id"), C("wx_app_secret"));
		$signs = $wxJssdk->getSignPackage();
		$this->assign('signs', $signs);
		$this->display();
	}
}
