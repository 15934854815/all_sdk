<?php
/**
 * 微信回调controller
 * @author liangjian <liangjian@bestfu.com>
 */
namespace Pot\Controller;
use Think\Controller;
use Pot\Service\WxCallbackApi;

class WxCallbackController extends Controller
{
	private $text_tpl;
	private $news_tpl;
	private $image_tpl;
	private $voice_tpl;
	public function _initialize(){
		$this->text_tpl = "<xml>
							<ToUserName><![CDATA[%s]]></ToUserName>
							<FromUserName><![CDATA[%s]]></FromUserName>
							<CreateTime>%s</CreateTime>
							<MsgType><![CDATA[%s]]></MsgType>
							<Content><![CDATA[%s]]></Content>
							<FuncFlag>0</FuncFlag>
							</xml>";
		$this->news_tpl = "<xml>
							<ToUserName><![CDATA[%s]]></ToUserName>
							<FromUserName><![CDATA[%s]]></FromUserName>
							<CreateTime>%s</CreateTime>
							<MsgType><![CDATA[%s]]></MsgType>
							<ArticleCount>%s</ArticleCount>
							<Articles>
							%s
							</Articles>
							<FuncFlag>0</FuncFlag>
							</xml>";
		$this->image_tpl = "<xml>
							<ToUserName><![CDATA[%s]]></ToUserName>
							<FromUserName><![CDATA[%s]]></FromUserName>
							<CreateTime>%s</CreateTime>
							<MsgType><![CDATA[%s]]></MsgType>
							<Image>
							<MediaId><![CDATA[%s]]></MediaId>
							</Image>
							</xml>";
		$this->voice_tpl = "<xml>
							<ToUserName><![CDATA[%s]]></ToUserName>
							<FromUserName><![CDATA[%s]]></FromUserName>
							<CreateTime>%s</CreateTime>
							<MsgType><![CDATA[%s]]></MsgType>
							<Voice>
							<MediaId><![CDATA[%s]]></MediaId>
							</Voice>
							</xml>";
	}
	
	public function valid(){
		$WxCallbackApi = new WxCallbackApi();
		$token = "psTbxYgwQrQEtEvGSuzPSBaEnaKr7taB";
		$WxCallbackApi->valid($token);
	}
	
	public function response(){
		$postStr = $GLOBALS["HTTP_RAW_POST_DATA"];

		if (!empty($postStr)){
            libxml_disable_entity_loader(true);
          	$postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
            $fromUsername = $postObj->FromUserName;
            $toUsername = $postObj->ToUserName;
			$msgType = $postObj->MsgType;
			$event = $postObj->Event;
			$eventKey = $postObj->EventKey;
            $keyword = trim($postObj->Content);
            $time = time();
            if($msgType == 'event'){
            	switch($event){
					case "subscribe":
						$msgType = "text";
                		$contentStr = '欢迎关注智慧盆栽公众号，首次关注请<a href="http://farm-api.bestfu.com/?s=Pot/Wifi/configure">配置网络</a>!';
						$resultStr = sprintf($this->text_tpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
						echo $resultStr;
						break;
					case "VIEW":
						/*$msgType = "text";
                		$contentStr = '欢迎关注智慧盆栽公众号，首次关注请<a href="http://farm-api.bestfu.com/?s=Pot/Wifi/configure">配置网络sss</a>!';
						$resultStr = sprintf($this->text_tpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
						echo $resultStr;*/
						break;
					default:
						break;
            	}
            }
        }else {
        	echo "";
        	exit;
        }
	}
}
