<?php
/**
 * 微信自定义菜单controller
 * @author liangjian <liangjian@bestfu.com>
 */
namespace Pot\Controller;
use Think\Controller;
use Pot\Service\WxJssdk;

class MenuController extends Controller
{
	public function create(){
		$admin = I("user", "", "string");
		if($admin == 'bestfu'){
			$wxJssdk = new WxJssdk(C("wx_app_id"), C("wx_app_secret"));
			$access_token = $wxJssdk->getAccessToken();
			$data = array();
			$data['button'] = array(
				array(
					"type"=>"view",
					"name"=>urlencode("状态"),
					//"url"=>"http://farm-api.bestfu.com/?s=Pot/Index/demo"
					"url"=>"https://open.weixin.qq.com/connect/oauth2/authorize?appid=".C("wx_app_id")."&redirect_uri=".urlencode("http://farm-api.bestfu.com/?s=Pot/Index/dddddd")."&response_type=code&scope=snsapi_base&state=1#wechat_redirect"
				),
				array(
					"name"=>urlencode("我的花盆"),
					"sub_button"=>array(
						array(
							"type"=>"view",
							"name"=>urlencode("设置"),
							"url"=>"http://farm-api.bestfu.com"
						),
						array(
							"type"=>"view",
							"name"=>urlencode("日志"),
							"url"=>"http://farm-api.bestfu.com"
						),
						array(
							"type"=>"view",
							"name"=>urlencode("浇水"),
							"url"=>"http://farm-api.bestfu.com"
						),
						array(
							"type"=>"view",
							"name"=>urlencode("状态"),
							"url"=>"http://farm-api.bestfu.com"
						),
					)
				),
				array(
					"name"=>urlencode("设置"),
					"sub_button"=>array(
						array(
							"type"=>"view",
							"name"=>urlencode("初始化"),
							"url"=>"http://farm-api.bestfu.com"
						),
						array(
							"type"=>"view",
							"name"=>urlencode("预警设置"),
							"url"=>"http://farm-api.bestfu.com"
						),
						array(
							"type"=>"view",
							"name"=>urlencode("网络监测"),
							"url"=>"http://farm-api.bestfu.com"
						),
						array(
							"type"=>"view",
							"name"=>urlencode("网络配置"),
							"url"=>"http://farm-api.bestfu.com/?s=Pot/Wifi/configure"
						),
					)
				)
			);
			$data = json_encode($data);
			$data = urldecode($data);
			//$data = preg_replace("#\\\u([0-9a-f]+)#ie", "iconv('UCS-2', 'UTF-8', pack('H4', '\\1'))", $data);
			$msg = $this->_curl_menu($access_token, $data);
	        if ($msg['errmsg'] == 'ok') {
	            echo '创建自定义菜单成功!';
	            exit;
	        } else {
	            echo '创建自定义菜单失败!';
	            exit;
	        }
		}else{
			echo "error!";
			exit;
		}
	}
	
	private function _curl_menu($ACCESS_TOKEN,$data)
    {
		$ch = curl_init(); 
		curl_setopt($ch, CURLOPT_URL, "https://api.weixin.qq.com/cgi-bin/menu/create?access_token=".$ACCESS_TOKEN); 
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_AUTOREFERER, 1); 
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
		$tmpInfo = curl_exec($ch); 
		if (curl_errno($ch)) {  
			echo 'Errno'.curl_error($ch);
		}
		curl_close($ch); 
		$arr= json_decode($tmpInfo,true);
		return $arr;
    }
}
