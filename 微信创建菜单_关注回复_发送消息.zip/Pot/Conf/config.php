<?php
return array(
	'SHOW_PAGE_TRACE'	=>	false,
	//'配置项'=>'配置值'
	
	'wx_app_id'		=>	'wx136cb67835e86f8e',
	'wx_app_secret'	=>	'c66cfb92ad483cbb100c6361b445c7b1',
);