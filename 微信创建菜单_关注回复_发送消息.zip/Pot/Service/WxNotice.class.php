<?php
/**
 * 微信通知接口Service
 */
namespace Pot\Service;

class WxNotice
{
	
}
